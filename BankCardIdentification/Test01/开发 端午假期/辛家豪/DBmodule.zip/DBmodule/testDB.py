import DB
import sqlite3

# 连接数据库
conn = sqlite3.connect('eighth.db')
c = conn.cursor()


####测试DB.py的函数
# addUser()
# dir={
#     'username':'用户二',
#     'sex':'女',
#     'nation':'北京',
#     'address':'大兴枣园'
# }
# result=DB.addUser(c,conn,dir)
#
# print(result)
#

# getUserData()
# result=DB.getUserData(c)
# print(*result)

# addCard()
dir={
    'username':'用户Ⅱ',
    'cardNO':111,
    'validity':'2021-01-01',
    'type':'借记卡',
    'bank':'中国银行'
}
result=DB.addCard(c,conn,dir)
print(result)

# getCardData()
result=DB.getCardData(c)
print(*result)



#关闭数据库
conn.close()