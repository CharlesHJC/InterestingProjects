from playsound import playsound
playsound("check.mp3")